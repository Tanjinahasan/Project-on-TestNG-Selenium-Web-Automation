package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class MyInfo {
    @FindBy(className = "oxd-text")      //myinfo- 5
    public List<WebElement> menu;

   @FindBy(className = "oxd-radio-input")
    public List<WebElement> gender;

   @FindBy(className = "oxd-select-text--arrow")      // 2
    public List<WebElement> bloodgroup;

//   @FindBy(className = "oxd-select-text-input" && tabindex = "0")     //2
//    public List<WebElement> bloodtype;
    @FindBy(className = "oxd-select-text")    //2
    public List<WebElement> bloodtype;

   @FindBy(className = "oxd-button")      //1
    public List<WebElement> save;

   public MyInfo(WebDriver driver){
       PageFactory.initElements(driver,this);
   }
}
