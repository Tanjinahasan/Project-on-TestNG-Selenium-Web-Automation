package testrunner;

import page.LoginPage;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import setup.Setup;

public class AssertNameTestRunner extends Setup {
    LoginPage loginPage;
    @BeforeTest
    public void doLogin(){
        loginPage=new LoginPage(driver);
        loginPage.doLogin("Admin", "admin123");
    }
    @Test
    public void assertName(){
      String ActualProfileName= driver.findElements(By.className("oxd-userdropdown-name")).get(0).getText();
      String ExpectedProfileName="Paul Collings";
      Assert.assertTrue(ActualProfileName.contains(ExpectedProfileName));
     //   Assert.assertEquals(ActualProfileName,ExpectedProfileName);
    }
}
