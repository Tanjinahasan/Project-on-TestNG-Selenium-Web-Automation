package testrunner;

import org.testng.annotations.BeforeClass;
import page.DashboardPage;
import page.EmployeeModel;
import page.LoginPage;
import com.github.javafaker.Faker;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import setup.Setup;
import utils.Utils;

import java.io.IOException;

public class DashboardTestRunner extends Setup {
    LoginPage loginPage;
    //@BeforeClass(groups = "smoke")
    @Test(priority = 1, description = "Dasboard login successfully", groups = "smoke")
    public void doLogin(){
        loginPage=new LoginPage(driver);
        loginPage.doLogin("Admin", "admin123");
    }
    @Test(priority = 2, groups = "smoke")
    public void createEmployee() throws InterruptedException, IOException, ParseException {
        DashboardPage dashboardPage=new DashboardPage(driver);
        dashboardPage.menu.get(1).click();
        dashboardPage.button.get(2).click();
        Faker faker=new Faker();
        String firstname= faker.name().firstName();
        String lastname= faker.name().lastName();
        driver.findElement(By.name("firstName")).sendKeys(firstname);
        driver.findElement(By.name("lastName")).sendKeys(lastname);
        String employeeid= driver.findElements(By.className("oxd-input")).get(4).getAttribute("value");
        driver.findElement(By.className("oxd-switch-input")).click();
        String username=faker.name().username();
        String password= Utils.generateRandomPassword(12);
        dashboardPage.txtFields.get(5).sendKeys(username);
        dashboardPage.txtFields.get(6).sendKeys(password);
        dashboardPage.txtFields.get(7).sendKeys(password);
        dashboardPage.button.get(1).click();
        Thread.sleep(7000);
        String titleActual= driver.findElements(By.className("orangehrm-main-title")).get(0).getText();
        String titleExpected="Personal Details";
     //   Assert.assertEquals(titleActual,titleExpected);
        Assert.assertTrue(titleActual.contains(titleExpected));

        EmployeeModel model=new EmployeeModel();
        model.setFirstname(firstname);
        model.setLastname(lastname);
        model.setUsername(username);
        model.setPassword(password);
        model.setEmployeeid(employeeid);
        Utils.saveInfo(model);
    }
}
